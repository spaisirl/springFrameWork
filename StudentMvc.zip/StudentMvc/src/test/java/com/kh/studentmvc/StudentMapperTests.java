package com.kh.studentmvc;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.studentmvc.domain.StudentVO;
import com.kh.studentmvc.mapper.StudentMapper;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class StudentMapperTests {

	@Autowired
	private StudentMapper studentMapper;
	
	
	@Test
	public void testInsert() {
		StudentVO studentVO = StudentVO.builder()
				.sno("2")
				.sname("김공대")
				.syear(3)
				.major("기공과")
				.gender("M")
				.score(30)
				.build();
		studentMapper.insert(studentVO);
	}
	
	@Test
	public void testGetList() {
		List<StudentVO> list = studentMapper.getList();
		for(StudentVO studentVO : list) {
			log.info("studentVO"+studentVO);
		}
		
	}
	
	@Test
	public void testDelete() {
		String sno = "1";
		int count = studentMapper.delete(sno);
		log.info("count:" + count);
	}
	
	@Test
	public void testUpdate() {
		StudentVO studentVO = StudentVO.builder()
				.sno("1")
				.sname("김국어")
				.syear(2)
				.major("국어")
				.gender("W")
				.score(60)
				.build();
		studentMapper.update(studentVO);
	}
	
}
