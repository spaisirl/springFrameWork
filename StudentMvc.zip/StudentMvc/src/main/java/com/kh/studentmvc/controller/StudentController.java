package com.kh.studentmvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.kh.studentmvc.domain.StudentVO;
import com.kh.studentmvc.service.StudentService;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/*")
@Log4j
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/list")
	public void list(Model model) {
		List<StudentVO> list = studentService.getList();
		model.addAttribute("list",list);
	}
	
	@GetMapping("/register")
	public String register() {
		
		return "/register";
	}
	@PostMapping("/register")
	public String register(StudentVO studentVO) {
		studentService.register(studentVO);
		return "redirect:/list";
	}
	
	@GetMapping("/modify")
	public String modify(String sno, Model model) {
		StudentVO studentVO  = studentService.findSno(sno);
		model.addAttribute("studentVO",studentVO);
		return "/modify";
	}
	
	@PostMapping("/modify")
	public String modify(StudentVO studentVO) {
		studentService.modify(studentVO);
		return "redirect:/list";
	}
	
	@GetMapping("/remove")
	public String remove(String sno) {
		studentService.remove(sno);
		return "redirect:/list";
	}
}
