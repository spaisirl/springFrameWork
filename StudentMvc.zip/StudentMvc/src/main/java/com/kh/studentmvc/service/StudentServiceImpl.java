package com.kh.studentmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.studentmvc.domain.StudentVO;
import com.kh.studentmvc.mapper.StudentMapper;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentMapper studentMapper;

	@Override
	public List<StudentVO> getList() {
		List<StudentVO> list = studentMapper.getList();
		return list;
		
	}

	@Override
	public void register(StudentVO studentVO) {
		
		studentMapper.insert(studentVO);
		
	}

	@Override
	public int modify(StudentVO studentVO) {
		 int count =studentMapper.update(studentVO);
		return count;
	}

	@Override
	public int remove(String sno) {
		int count = studentMapper.delete(sno);
		return count;
	}

	
	@Override
	public StudentVO findSno(String sno) {
		StudentVO studentVO = studentMapper.findSno(sno);
		return studentVO;
	}

	
}
