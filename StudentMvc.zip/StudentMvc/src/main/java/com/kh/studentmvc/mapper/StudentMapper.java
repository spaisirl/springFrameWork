package com.kh.studentmvc.mapper;

import java.util.List;

import com.kh.studentmvc.domain.StudentVO;

public interface StudentMapper {
	
	public List<StudentVO> getList();
	
	public void insert(StudentVO studentVO);
	
	public StudentVO findSno(String sno);
	
	public int update(StudentVO studentVO);
	
	public int delete(String sno);

}
