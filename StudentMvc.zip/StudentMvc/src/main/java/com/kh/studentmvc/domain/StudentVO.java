package com.kh.studentmvc.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class StudentVO {
	
	private String sno;
	private String sname;
	private Integer syear;
	private String gender;
	private String major;
	private Integer score;
	

}
