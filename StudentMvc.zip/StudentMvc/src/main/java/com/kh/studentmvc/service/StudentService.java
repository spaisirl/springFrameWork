package com.kh.studentmvc.service;

import java.util.List;
import java.util.Map;

import com.kh.studentmvc.domain.StudentVO;

public interface StudentService {
	
	public List<StudentVO> getList();
	
	public void register(StudentVO studentVO);
	
	public StudentVO findSno(String sno);
	
	public int modify(StudentVO studentVO);
	
	public int remove(String sno);
}
