package com.kh.ex02.mapper;

import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.ex02.domain.BoardAttachVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration

public class BoardAttachMapperTests {
	
	@Autowired
	private BoardAttachMapper boardAttachMapper;
	
	@Test
	public void testInsert() {
		// 여기서는 void  사용 법칙에 따라 void 이용.
		for (int i = 1; i <=3; i++) {
			BoardAttachVO boardAttachVO = BoardAttachVO.builder()
				.uuid(UUID.randomUUID().toString())
				.upload_path("G:/upload/2024/01/05")
				.file_name("smile" + i + ".png")
				.file_type("I")
				.bno(500L)
				.build();
			boardAttachMapper.insert(boardAttachVO);
		}
	}
	
	@Test
	public void testDelete() {
		String uuid = "05f6ade3-e128-438b-81ca-39eece4c049a";
		boardAttachMapper.delete(uuid);
	
	}
	
	@Test
	public void testFindByBno() {
		Long bno = 500L;
		List<BoardAttachVO> list = boardAttachMapper.findByBno(bno);
		log.info("list" + list);
	}
}
