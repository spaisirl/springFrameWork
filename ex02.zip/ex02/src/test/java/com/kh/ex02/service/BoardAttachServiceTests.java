package com.kh.ex02.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.ex02.domain.BoardAttachVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class BoardAttachServiceTests {

		@Autowired
		private BoardAttachService boardAttachService;
		
		@Test
		public void testAddList() {
			Long bno = 549L;
			List<BoardAttachVO> oldList = boardAttachService.findByBno(bno);
		
			List<BoardAttachVO> newList = new ArrayList<>();
			
			if (oldList.size() == 0) {
				return;
			}
			
			for (int i = 1; i < oldList.size(); i++) {
				newList.add(oldList.get(i));
				
			}
			
			BoardAttachVO vo = BoardAttachVO.builder()
					.uuid("abcd")
					.file_name("1.png")
					.file_type("I")
					.bno(bno)
					.upload_path(oldList.get(1).getUpload_path())
					.build();
			newList.add(vo);
			
			log.info("oldList:" + oldList);
			log.info("newList:" + newList);
			
			List<BoardAttachVO> addList = new ArrayList<>();
			for (int i = 0; i < newList.size(); i++) {
				BoardAttachVO newVO = newList.get(i);
				String uuid = newVO.getUuid();
				boolean isAdded = true;
				for (BoardAttachVO attachVO : oldList) {
					if (uuid.equals(attachVO.getUuid())) {
						isAdded = false;
						break;
					}
				}
				if (isAdded) {
					addList.add(newVO);
					
				}
			}
			
			log.info("addList:" + addList);
			
		}
		
		@Test
		public void testDelList() {
			Long bno = 549L;
			List<BoardAttachVO> oldList = boardAttachService.findByBno(bno);
		
			List<BoardAttachVO> newList = new ArrayList<>();
			newList.add(oldList.get(1));
			newList.add(oldList.get(2));
			BoardAttachVO vo = BoardAttachVO.builder()
					.uuid("abcd")
					.file_name("1.png")
					.file_type("I")
					.bno(bno)
					.upload_path(oldList.get(1).getUpload_path())
					.build();
			newList.add(vo);
			
			log.info("oldList:" + oldList);
			log.info("newList:" + newList);
			
			List<BoardAttachVO> delList = new ArrayList<>();
			for (int i = 0; i < oldList.size(); i++) {
				BoardAttachVO oldVO = oldList.get(i);
				String uuid = oldVO.getUuid();
				boolean isDeleted = true;
				for (BoardAttachVO attachVO : newList) {
					if (uuid.equals(attachVO.getUuid())) {
						isDeleted = false;
						break;
					}
				}
				if (isDeleted) {
					delList.add(oldVO);
					
				}
			}
			
			log.info("delList:" + delList);
			
		}

}
