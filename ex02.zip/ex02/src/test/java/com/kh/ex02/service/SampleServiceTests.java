package com.kh.ex02.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class SampleServiceTests {
	
	@Autowired
	private SampleService sampleService;
	
	@Test
	public void testObj() throws Exception {
		log.info("sampleService:" + sampleService);
		log.info("className:" + sampleService.getClass().getName());
		int result = sampleService.doAdd("100", "200");
		log.info("result:" + result);
//		assertEquals(result, 300);
		int result2 = sampleService.doSub("100", "200");
		log.info("result2:" + result2);
		assertEquals(result2, -100);
	}
}
