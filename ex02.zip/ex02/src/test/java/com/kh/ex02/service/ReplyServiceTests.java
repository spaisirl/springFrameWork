package com.kh.ex02.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.ex02.domain.ReplyVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class ReplyServiceTests {
	
	@Autowired
	private ReplyService replyService;
	
	@Test
	public void testGet() {
		ReplyVO replyVO = replyService.get(12L);
		log.info("replyVO" + replyVO);
//		assertEquals(replyVO.getReply(), "댓글1-수정");
		assertNull(replyVO);
	}
	
	@Test
	public void testGetList() {
		List<ReplyVO> list = replyService.getList(500L);
		log.info("list" + list);
		assertEquals(list.size(), 20);
	}
	
	@Test
	public void testRegister() {
		ReplyVO replyVO = ReplyVO.builder()
				.bno(500L)
				.reply("새로운 댓글-1")
				.replyer("새로운 댓글러-1")
				.build();
		
		int count = replyService.register(replyVO);
		log.info("count" + count);
		assertEquals(count, 1);
	}
	
	@Test
	public void testRemove() {
		int count = replyService.remove(44L);
		assertEquals(count, 1);
	}
	
	@Test
	public void testModify() {
		ReplyVO replyVO = ReplyVO.builder()
				.reply("댓글1-수정")
				.replyer("댓글러1-수정")
				.rno(12L)
				.build();
		int count = replyService.modify(replyVO);
		log.info("count:" + count);
		assertEquals(count, 1);
	}
	
	

}
