package com.kh.ex02.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class SampleTXServiceTests {
	
	@Autowired
	private SampleTXService service;
	
	@Test
	public void testAddData() {
		String value = "";
		for(int i = 0; i < 10; i++) {
			value += "a";
		}
		service.addData(value);
	}

}
