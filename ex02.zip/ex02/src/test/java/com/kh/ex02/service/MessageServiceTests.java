package com.kh.ex02.service;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.ex02.domain.MessageVO;
import com.kh.ex02.domain.PointVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class MessageServiceTests {
	
	@Autowired
	private MessageService messageService;
	
	@Test
	public void testSendMessage() {
		Map<String, Object> map = new HashMap<String, Object>();
		MessageVO messageVO = MessageVO.builder()
				.sender("MEMBER00")
				.receiver("MEMBER01")
				.message("Hello-헬로우")
				.build();
		
		PointVO pointVO = PointVO.builder()
				.mid("MEMBER00")
				.ppoint(10)
				.point_code("MS")
				.build();
		Map<String, Object> pointMap = new HashMap<String, Object>();
		pointMap.put("ppoint", 10);
		pointMap.put("mid", "MEMBER00");
		
		map.put("messageVO", messageVO);
		map.put("pointVO", pointVO);
		map.put("pointMap", pointMap);
		
		messageService.sendMessage(map);
		
	};

}
