package com.kh.ex02.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.ex02.domain.ReplyVO;
import com.kh.ex02.service.ReplyService;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class ReplyMapperTests {
	
	@Autowired
	private ReplyMapper replyMapper;
	
	@Test
	public void testInsert() {
		for (int i = 1; i <= 10; i++) {
			ReplyVO replyVO = ReplyVO.builder()
				.bno(501L)
				.reply("댓글-1")
				.replyer("댓글러-1")
				.build();
			replyMapper.insert(replyVO);
		}
				
	}
	
	@Test
	public void testSelectByRno() {
		Long rno = 1L;
		ReplyVO replyVO = replyMapper.selectByRno(rno);
		log.info("replyVO" + replyVO);
	}
	
	@Test
	public void testUpdate() {
		ReplyVO replyVO = ReplyVO.builder()
				.reply("댓글1 - 수정")
				.replyer("댓글러1 - 수정")
				.rno(1L)
				.build();
		replyMapper.update(replyVO);
	}
	
	@Test
	public void testDelete() {
		Long rno = 1L;
		replyMapper.delete(rno);
		
	}
	
	@Test
	public void testSelectList() {
		List<ReplyVO> list = replyMapper.selectList(500L);
		for (ReplyVO replyVO : list) {
			log.info("replyVO" + replyVO);
		}
	}
	
	
}
