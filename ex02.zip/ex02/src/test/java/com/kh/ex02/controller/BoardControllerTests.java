package com.kh.ex02.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class BoardControllerTests {
	
	@Autowired
	private WebApplicationContext context; // server
	
	private MockMvc mvc; // client

	// org.junit.Before
	@Before
	public void setup() {
		mvc = MockMvcBuilders.webAppContextSetup(context).build();
	}
	
	@Test
	public void testList() throws Exception {
		ModelAndView mav = mvc.perform(
				MockMvcRequestBuilders.get("/board/list")
				.param("pageNum", "51")
				.param("amount", "10")
				)
			.andReturn()
			.getModelAndView();
		// model.addAttribute()
		ModelMap map = mav.getModelMap();
		// forward
		String viewName = mav.getViewName();
		log.info("map:" + map);
		log.info("viewName:" + viewName);
	}
	
	@Test
	public void testRegisterGet() throws Exception {
		ModelAndView mav = mvc.perform(
				MockMvcRequestBuilders.get("/board/register"))
			.andReturn()
			.getModelAndView();
		// forward
		String viewName = mav.getViewName();
		log.info("viewName:" + viewName);
	}
	
	@Test
	public void testRegisterPost() throws Exception {
		ModelAndView mav = mvc.perform(
				MockMvcRequestBuilders.post("/board/register")
				.param("title", "테스트 5")
				.param("content", "테스트 5 ...")
				.param("writer", "tester05"))
			.andReturn()
			.getModelAndView();
		// forward
		String viewName = mav.getViewName();
		log.info("viewName:" + viewName);
	}
	
	@Test
	public void testRead() throws Exception {
		ModelAndView mav = mvc.perform(
				MockMvcRequestBuilders.get("/board/read")
				.param("bno", "13"))
			.andReturn()
			.getModelAndView();
		// model.addAttribute()
		ModelMap map = mav.getModelMap();
		// forward
		String viewName = mav.getViewName();
		log.info("map:" + map);
		log.info("viewName:" + viewName);
	}
	
	@Test
	public void testModify() throws Exception {
		String str = "<script>";
		str += "		alert('동영이 바보');";
		str += "</script>";
		ModelAndView mav = mvc.perform(
				MockMvcRequestBuilders.post("/board/modify")
				.param("bno", "13")
				.param("title", "스크립트 테스트")
				.param("content", str)
				.param("writer", "작성자-14 수정"))
			.andReturn()
			.getModelAndView();
		// model.addAttribute()
		ModelMap map = mav.getModelMap();
		// forward
		String viewName = mav.getViewName();
		log.info("map:" + map);
		log.info("viewName:" + viewName);
	}
	
	@Test
	public void testRemove() throws Exception {
		ModelAndView mav = mvc.perform(
				MockMvcRequestBuilders.post("/board/remove")
				.param("bno", "15"))
			.andReturn()
			.getModelAndView();
		// model.addAttribute()
		ModelMap map = mav.getModelMap();
		// forward
		String viewName = mav.getViewName();
		log.info("map:" + map);
		log.info("viewName:" + viewName);
	}
}
