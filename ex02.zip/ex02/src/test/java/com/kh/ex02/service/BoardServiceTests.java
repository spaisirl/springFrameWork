package com.kh.ex02.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.kh.ex02.domain.BoardAttachVO;
import com.kh.ex02.domain.BoardVO;
import com.kh.ex02.domain.Criteria;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@Log4j
@WebAppConfiguration
public class BoardServiceTests {

	@Autowired
	private BoardService boardService;
	
	@Test
	public void testGetList() {
		log.info("boardService:" + boardService);
		Criteria cri = new Criteria();
		@SuppressWarnings("unchecked")
		List<BoardVO> list = (List<BoardVO>)boardService.getList(cri).get("list");
		log.info("list:" + list);
	}
	
	@Test
	public void testRegister() {
		List<BoardAttachVO> attachList = new ArrayList<BoardAttachVO>();
			for (int i = 1; i <=3; i++) {
				BoardAttachVO boardAttachVO = BoardAttachVO.builder()
						.uuid(UUID.randomUUID().toString())
						.upload_path("G:/upload/2024/01/05")
						.file_name("angry" + i + ".png")
						.file_type("I")
						.build();
				attachList.add(boardAttachVO);
			}
		boardService.register(BoardVO.builder()
				.title("제목-501")
				.content("내용-501")
				.writer("작성자-501")
				.attachList(attachList)
				.build());
	}
	
	@Test
	public void testGet() {
		BoardVO boardVO = boardService.get(13L);
		log.info("boardVO:" + boardVO);
	}
	
	@Test
	public void testRemove() {
		boolean result = boardService.remove(14L);
		log.info("result:" + result);
	}
	
	@Test
	public void testModify() {
		boolean result = boardService.modify(BoardVO.builder()
				.title("제목-13 수정")
				.content("내용-13 수정")
				.writer("작성자-13 수정")
				.bno(13L)
				.build());
		log.info("result:" + result);
	}
}
