package com.kh.ex02.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/*.xml"})
@Log4j
@WebAppConfiguration
public class MessageMapperTests {
	
	@Autowired
	private MessageMapper messageMapper;
	
	@Transactional
	@Test
	public void testDeleteByIds() {
		String msg_ids = "2,1";
		messageMapper.deleteByIds(msg_ids);
	}

}
