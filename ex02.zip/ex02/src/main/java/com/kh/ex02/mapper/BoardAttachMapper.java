package com.kh.ex02.mapper;

import java.util.List;

import com.kh.ex02.domain.BoardAttachVO;

public interface BoardAttachMapper {
	
	public void insert(BoardAttachVO boardAttachVO);
	
	public void delete(String uuid);
	
	public void deleteByBno(Long bno);
	
	public List<BoardAttachVO> findByBno(Long bno);
	
}
