package com.kh.ex02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kh.ex02.mapper.Sample1Mapper;
import com.kh.ex02.mapper.Sample2Mapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class SampleTXServiceImpl implements SampleTXService {

	@Autowired
	private Sample1Mapper sample1Mapper;
	
	@Autowired
	private Sample2Mapper sample2Mapper;
	
	@Transactional
	@Override
	public void addData(String value) {
		
		log.info("sample1Mapper");
		sample1Mapper.insertCol1(value);
		log.info("sample2Mapper");
		sample2Mapper.insertCol2(value);
		log.info("finish");
		
	}

}
