package com.kh.ex02.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kh.ex02.domain.BoardAttachVO;
import com.kh.ex02.domain.BoardVO;
import com.kh.ex02.domain.Criteria;
import com.kh.ex02.mapper.BoardAttachMapper;
import com.kh.ex02.mapper.BoardMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@RequiredArgsConstructor
@Log4j
public class BoardServiceImpl implements BoardService {
	
	private final BoardMapper boardMapper;
	private final BoardAttachMapper boardAttachMapper;

	@Override
	public Map<String, Object> getList(Criteria cri) {
//		log.info("boardMapper:" + boardMapper);
		List<BoardVO> list = boardMapper.getList(cri);
		int total = boardMapper.getTotal(cri);
		Map<String, Object> map = new HashMap<>();
		map.put("list", list);
		map.put("total", total);
		return map;
	}
	
	@Transactional
	@Override
	public Long register(BoardVO boardVO) {
		Long bno = boardMapper.selectNextval();
		boardVO.setBno(bno);
		boardMapper.insert(boardVO);
		// 첨부파일 - boardVO.attachList
		List<BoardAttachVO> attachList = boardVO.getAttachList();
		if (attachList != null && attachList.size() > 0) {
			for (BoardAttachVO boardAttachVO : boardVO.getAttachList()) {
				boardAttachVO.setBno(bno); 
				// BoardServicTests - testRegister 에서 bno 값을 설정하지 않아서 여기서 설정.
				boardAttachMapper.insert(boardAttachVO);
			}
		
		}
		return bno;
	}

	@Override
	public BoardVO get(Long bno) {
		// 
		List<BoardAttachVO> attachList = boardAttachMapper.findByBno(bno);
		BoardVO boardVO = boardMapper.read(bno);
		boardVO.setAttachList(attachList);
		return boardVO;
	}
	

	@Transactional
	@Override
	public boolean remove(Long bno) {
		
		// 데이터를 삭제하기 전에 첨부파일 목록 얻어오기
		// 첨부 파일 목록 가져오기 -> attachList 에 저장
		List<BoardAttachVO> attachList = boardAttachMapper.findByBno(bno);

		// 첨부 파일 데이터 하나 가져오기 -> attachList.get(0) -> boardAttachVO에 저장
		boardAttachMapper.deleteByBno(bno);

		// tbl_board 에서 해당 글삭제
		int count = boardMapper.delete(bno);
		
		// 데이터에서 파일 객체 생성에 필요한 값 얻어오기 -> boardAttachVO 에서 getXxx() -> 각 변수에 저장

		// 얻어온 데이터를 이용해서 파일 객체 생성 -> 저장된 변수를 이용해서 파일 경로 생성 -> 파일 객체에 저장

		// 생성된 파일 객체를 이용해서 파일 삭제 -> 저장된 파일 객체를 이용해서 삭제
		
		
		
		//첨부파일 목록을 가져와서 
		
		for(BoardAttachVO boardAttachVO : attachList) {
			String upload_path = boardAttachVO.getUpload_path();
			String uuid = boardAttachVO.getUuid();
			String file_name = boardAttachVO.getFile_name();
			String file_path = "G:/upload" + upload_path + "/" + uuid + "_" + file_name;
			File f = new File(file_path);
			if (f.exists()) {
				f.delete();
			}
			// 이미지 파일이라면 썸네일 이미지 삭제
			if (boardAttachVO.getFile_type().equals("I")) {
				String thumbnail_path = "G:/upload" + upload_path + "/s_" + uuid + "_" + file_name;
				log.info("thumbnail_path" + thumbnail_path);
				File f2 = new File(thumbnail_path);
				if (f2.exists()) {
					f2.delete();
				}
			}
		}
		// 파일 삭제 - 파일 객체 생성 - .delete()
		
		// tbl_attach 에서 해당 글번호에 대한 데이터 삭제

		if (count == 1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean modify(BoardVO boardVO) {
		
		List<BoardAttachVO> newList = boardVO.getAttachList();
		List<BoardAttachVO> oldList = boardAttachMapper.findByBno(boardVO.getBno());
		
		List<BoardAttachVO> delList = getDeletedList(oldList, newList, boardVO.getBno());
		for (BoardAttachVO vo : delList) {
			boardAttachMapper.delete(vo.getUuid());
			String uploadPath = vo.getUpload_path();
			String uuid = vo.getUuid();
			String fileName = vo.getFile_name();
			String filePath = "G:/upload" + uploadPath + "/s_" + uuid + "_" + fileName;
			File f = new File(filePath);
			if (f.exists()) {
				f.delete();
			}
			
			// 이미지 파일이라면 섬네일 삭제
			if (vo.getFile_type().equals("I")) {
				String thumbnailPath = "D:/upload" + uploadPath + "/s_" + uuid + "_" + fileName;
				File f2 = new File(thumbnailPath);
				if (f2.exists()) {
					f2.delete();
				}
				
			}
			
			
		}
		
		// 추가된 첨부파일 데이터 추가
		List<BoardAttachVO> addList = getAddedList(oldList, newList, boardVO.getBno());
		for (BoardAttachVO vo : addList) {
			vo.setBno(boardVO.getBno());
			boardAttachMapper.insert(vo);
		}
		
		int count = boardMapper.update(boardVO);
		if (count == 1) {
			return true;
		}
		return false;
	}
	
	private List<BoardAttachVO> getDeletedList(
			List<BoardAttachVO> oldList,
			List<BoardAttachVO> newList,
			Long bno) {
		
		List<BoardAttachVO> delList = new ArrayList<>();
		for (int i = 0; i < oldList.size(); i++) {
			BoardAttachVO oldVO = oldList.get(i);
			String uuid = oldVO.getUuid();
			boolean isDeleted = true;
			for (BoardAttachVO attachVO : newList) {
				if (uuid.equals(attachVO.getUuid())) {
					isDeleted = false;
					break;
				}
			}
			if (isDeleted) {
				delList.add(oldVO);
				
			}
		}
		
		return delList;
		
	}
		
	
	private List<BoardAttachVO> getAddedList(
			List<BoardAttachVO> oldList, 
			List<BoardAttachVO> newList, 
			Long bno) {
			
		List<BoardAttachVO> addList = new ArrayList<>();
		for (int i = 0; i < newList.size(); i++) {
			BoardAttachVO newVO = newList.get(i);
			String uuid = newVO.getUuid();
			boolean isAdded = true;
			for (BoardAttachVO attachVO : oldList) {
				if (uuid.equals(attachVO.getUuid())) {
					isAdded = false;
					break;
				}
			}
			if (isAdded) {
				addList.add(newVO);
				
			}
		}
		
		return addList;
		
		
	}
	


	
}
