package com.kh.ex02.mapper;

import java.util.List;

import com.kh.ex02.domain.MessageVO;
import com.kh.ex02.domain.ReadMessageDTO;

public interface MessageMapper {
	public int insertMessage(MessageVO messageVO);
	public int getCountNotRead(String mid);
	public List<MessageVO> listSend(String mid);
	public List<MessageVO> listReceive(String mid);
	public int updateOpenDate(Long msg_id);
	public ReadMessageDTO selectById(Long msg_id);
	public int deleteByIds(String msg_ids);
	public int updateOpenDateByIds(String msg_ids);
	public String selectOpenDateById(String msg_id);
}
