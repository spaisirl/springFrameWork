package com.kh.ex02.mapper;

import com.kh.ex02.domain.PointVO;

public interface PointMapper {
	public int insertPoint(PointVO pointVO);

}
