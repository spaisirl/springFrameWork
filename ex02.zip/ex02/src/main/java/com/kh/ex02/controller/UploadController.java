package com.kh.ex02.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.kh.ex02.domain.AttachFileDTO;

import lombok.extern.log4j.Log4j;
import net.coobird.thumbnailator.Thumbnailator;

@Controller
@Log4j
public class UploadController {
	
	private final String UPLOAD_PATH = "G:/upload";

	@GetMapping("/uploadForm")
	public void uploadForm() {
		log.info("uploadForm...");
	}
	
	@PostMapping("/uploadFormAction")
	public void uploadFormPost(MultipartFile[] uploadFile) {
		log.info("uploadFormPost...");
		log.info("uploadFile:" + uploadFile);
		log.info("length:" + uploadFile.length);
//		String uploadPath = "D:/upload";
		for (int i = 0; i < uploadFile.length; i++) {
			log.info("---------------------------");
			log.info("name:" + uploadFile[i].getName()); // <input name="uploadFile"
			log.info("filename:" + uploadFile[i].getOriginalFilename());
			log.info("size:" + uploadFile[i].getSize());
			UUID uuid = UUID.randomUUID();
			File f = new File(UPLOAD_PATH, uuid + "_" + uploadFile[i].getOriginalFilename());
			try {
				uploadFile[i].transferTo(f);
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
	}
	
	// localhost/uploadAjax
	@GetMapping("/uploadAjax")
	public void uploadAjax() {
		
	}
	
	@PostMapping(value = "/uploadAjaxAction",
				 produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<AttachFileDTO> uploadAjaxPost(MultipartFile[] uploadFile) {
		log.info("uploadAjaxPost...");
		log.info("uploadFile:" + uploadFile);
		log.info("length:" + uploadFile.length);
		String uploadPath = getFolder();
		
		List<AttachFileDTO> attachList = new ArrayList<>();
		
		for (int i = 0; i < uploadFile.length; i++) {
			
			log.info("---------------------------");
			log.info("name:" + uploadFile[i].getName()); // <input name="uploadFile"
			log.info("filename:" + uploadFile[i].getOriginalFilename());
			log.info("size:" + uploadFile[i].getSize());
			UUID uuid = UUID.randomUUID();
			String orgFilename = uploadFile[i].getOriginalFilename();
			String savedFilename = uuid + "_" + orgFilename;
			File f = new File(uploadPath, savedFilename);
			// -> D:/upload/<uuid>_파일명
			// 업로드 된 파일이 이미지라면
			boolean isImage = checkImageType(f);
			
			AttachFileDTO attachDTO = AttachFileDTO.builder()
					.fileName(orgFilename)
					.uploadPath(uploadPath.substring(UPLOAD_PATH.length()))
					.uuid(uuid.toString())
					.image(isImage)
					.build();
			attachList.add(attachDTO);
			
			
			if (isImage) {
				// 썸네일 이미지를 만든다.
				// 저장된 파일을 읽어서 썸네일 파일(s_저장파일명)로 쓰기
				try {
					FileOutputStream thumbnail = 
							new FileOutputStream(
									new File(uploadPath, "s_" + savedFilename));
					Thumbnailator.createThumbnail(
							uploadFile[i].getInputStream(), thumbnail, 100, 100);
					thumbnail.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			try {
				uploadFile[i].transferTo(f);
			} catch (Exception e) {
				e.printStackTrace();
			} 
		} // for
		
		return attachList;
	}
	
	private String getFolder() {
		// java.util.Date
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		String str = UPLOAD_PATH + "/" + sdf.format(d);
		// -> D:/upload/2024/01/03
		File f = new File(str);
		if (!f.exists()) {
			f.mkdirs();
		}
		return str;
	}
	
	private boolean checkImageType(File savedFile) {
		// image/jpeg, image/png, image/gif - MIME-TYPE 체크
		// java.nio.Files
		try {
			String mimeType = Files.probeContentType(savedFile.toPath());
			log.info("mimeType:" + mimeType);
			// mimeType 이 "image/"로 시작하는가
			return mimeType.startsWith("image");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@GetMapping("/display")
	public ResponseEntity<byte[]> getFile(String fileName) {
		// -> /2024/01/04/s_6e8e7332-e4e5-415c-9dbd-422c2cd7ae65_4.png
		String filePath = UPLOAD_PATH + fileName;
		File target = new File(filePath);
		try {
			byte[] data = FileCopyUtils.copyToByteArray(target);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", Files.probeContentType(target.toPath()));
			ResponseEntity<byte[]> entity = 
					new ResponseEntity<>(data, headers, HttpStatus.OK);
			return entity;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = "/download",
				produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	@ResponseBody
	public ResponseEntity<byte[]> downloadFile(String fileName) {
		// -> /2024/01/04/afdcf6ee-fee1-4acc-941d-61f6cee3e7ac_4.png
		String filePath = UPLOAD_PATH + fileName;
		File target = new File(filePath);
		try {
			byte[] data = FileCopyUtils.copyToByteArray(target);
			HttpHeaders headers = new HttpHeaders();
			String downloadName = fileName.substring(fileName.indexOf("_") + 1);
			headers.add("Content-Disposition", "attachment; filename=" 
							+ URLEncoder.encode(downloadName, "utf-8").replace("+", " "));
			// -> 4.png
			ResponseEntity<byte[]> entity =
						new ResponseEntity<byte[]>(data, headers, HttpStatus.OK);
			return entity;
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	// 삭제 엔티디로 받기
	@PostMapping("/deleteFile")
	public ResponseEntity<String> deleteFile(String fileName, String dataType) {
		log.info("fileName:" + fileName);
		log.info("dataType:" + dataType);
		// 파일 삭제 처리
		// 1. 원본 파일 삭제
		String filePath = UPLOAD_PATH + fileName;
		File f = new File(filePath);
		boolean result = f.delete();
		// 2. 이미지 파일이라면 썸네일 파일 삭제
		if (dataType.equals("image")) {
			String front = fileName.substring(0,12); // 2024/01/05
			String rear = fileName.substring(12);
			String thumbnailPath = UPLOAD_PATH + front + "s_" + rear;
			File thumbF = new File(thumbnailPath);
			result = result && thumbF.delete();
		}
				
		ResponseEntity<String> entity = new ResponseEntity<String>(
				String.valueOf(result), HttpStatus.OK);
		return entity;
	}
} // class
