package com.kh.ex02.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.kh.ex02.domain.LoginDTO;
import com.kh.ex02.domain.MemberVO;
import com.kh.ex02.service.MemberSerivce;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
public class MemberController {
	
	@Autowired
	private MemberSerivce memberSerivce;
	
	@GetMapping("/login")
	public void login() {
		
	}
	
	@PostMapping("/loginPost")
	public void loginPost(LoginDTO loginDTO, Model model) {
		log.info("loginDTO" + loginDTO);
		MemberVO memberVO = memberSerivce.login(loginDTO);
//		if (memberVO == null) {
//			
//		}
		model.addAttribute("loginInfo", memberVO);
		
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/login";
	}
	
	@GetMapping("/register")
	public void register() {
		
	} 
	
	@PostMapping("/registerPost")
	public String registerPost(MemberVO memberVO, RedirectAttributes rttr) {
		boolean result = memberSerivce.registerPost(memberVO);
		rttr.addFlashAttribute("registerResult", String.valueOf(result));
		return "redirect:/login";
	}
}
