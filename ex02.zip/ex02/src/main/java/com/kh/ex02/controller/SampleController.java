package com.kh.ex02.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kh.ex02.domain.BoardVO;
import com.kh.ex02.domain.Ticket;

import lombok.extern.log4j.Log4j;

@RestController
@RequestMapping("/sample")
@Log4j
public class SampleController {
	
	@GetMapping(value = "/getText", produces = "text/plain;charset=utf-8")
	public String getText() {
		log.info(MediaType.TEXT_PLAIN_VALUE);
		log.info(MediaType.APPLICATION_JSON_UTF8_VALUE);
		return "Hello, 안녕하세요";
	}
	@GetMapping(value = "/getBoard", produces = {MediaType.APPLICATION_JSON_VALUE,
												MediaType.APPLICATION_XML_VALUE})
	public BoardVO getBoardVO() {
		
		BoardVO boardVO = BoardVO.builder()
				.bno(1L)
				.title("제목-1")
				.content("내용-1")
				.writer("작성자-1")
				.build();
		
		return boardVO;
	}
	
	@GetMapping("/getList")
	public List<BoardVO> getList() {
		List<BoardVO> list = new ArrayList<>();
		for (int i =1; i <= 10; i++) {
			BoardVO boardVO = BoardVO.builder()
					.bno((long)i)
					.title("제목-" + i)
					.content("내용-" + i)
					.writer("작성자-" + i)
					.build();
			list.add(boardVO);
			
		}
		return list;
	}
	
	@GetMapping("/getMap")
	public Map<String, BoardVO> getMap() {
		Map<String, BoardVO> map = new HashMap<>();
		BoardVO boardVO = BoardVO.builder()
				.bno(1L)
				.title("제목-1")
				.content("내용-1")
				.writer("작성자-1")
				.build();
		map.put("boardVO", boardVO);
		
		return map;
	}
	
	@GetMapping("/product/{cat}/{pid}")
	public String[] getPath(@PathVariable("cat") String cat, 
			@PathVariable("pid") Integer pid) {
		log.info("cat:" + cat);
		log.info("pid" + pid);
		return new String[] {cat, String.valueOf(pid)};
	}
	
	@GetMapping("/getTicket")
	public Ticket getTicket(Ticket ticket) {
		log.info("ticket:" + ticket);
		return ticket;
	}
}
