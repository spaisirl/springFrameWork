package com.kh.ex02.domain;

import org.springframework.web.util.UriComponentsBuilder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor

public class Criteria {
	private int pageNum;
	private int amount;
	private int startRow;
	private int endRow;
	
	//검색
	private String type; // 검색 조건 (제목-t, 내용-c, 작성자-w, TC, TW, TCM)
	private String keyword; // (사용자 입력)
	
	public Criteria() {
		this(1, 10, 1, 10);
		setRows();
	}
	
	public Criteria(int pageNum, int amount, int startRow, int endRow) {
		this.pageNum = pageNum;
		this.amount = amount;
		this.startRow = startRow;
		this.endRow = endRow;
	}
	
	private void setRows() {
		endRow = pageNum * amount;
		startRow = endRow - (amount - 1);
	}
	
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
		setRows();
		
	}
	
	public String[] getTypeArr() {
		return type == null ? new String[] {} : type.split("");
	}
	
	public String getLink() {
		String path = "";
		UriComponentsBuilder builder = UriComponentsBuilder.fromPath(path)
				.queryParam("pageNum", this.pageNum)
				.queryParam("amount", this.amount)
				.queryParam("type", this.getType())
				.queryParam("keyword", this.keyword);
		return builder.toUriString();
			
	}
	
}


