package com.kh.ex02.interceptor;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.core.MethodParameter;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import lombok.extern.log4j.Log4j;

@Log4j
public class SampleInterceptor extends HandlerInterceptorAdapter {
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		log.info("preHandle");
		log.info("handler" + handler.getClass().getName());
		HandlerMethod handlerMethod = (HandlerMethod)handler;
		MethodParameter[] params = handlerMethod.getMethodParameters();
		for (MethodParameter param : params) {
			Class<?> clazz = param.getParameterType();
			String name = param.getParameterName();
			log.info(clazz + "," + name);
		}
		return true; // true : 요청 수행, false 수행하지 않음
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		log.info("postHandle");
		Map<String, Object> map = modelAndView.getModel();
		map.put("greeting", "hello");
		String viewName = modelAndView.getViewName();
		// doA.jsp 가 나와야 하지 않을까?
		log.info("viewName" + viewName);
		
		HttpSession session = request.getSession();
		session.setAttribute("id", "hong");
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
		log.info("afterCompletion");
		log.info("ex" + ex);
		
		
	}
	
	
}
