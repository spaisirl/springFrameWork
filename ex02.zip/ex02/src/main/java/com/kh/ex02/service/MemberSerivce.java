package com.kh.ex02.service;

import com.kh.ex02.domain.LoginDTO;
import com.kh.ex02.domain.MemberVO;

public interface MemberSerivce {
	
	public MemberVO login(LoginDTO loginDTO);
	
	public boolean registerPost(MemberVO memberVO);
}
