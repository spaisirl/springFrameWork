package com.kh.ex02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.ex02.domain.LikeVO;
import com.kh.ex02.mapper.LikeMapper;

@Service
public class LikeServiceImpl implements LikeService {
	
	@Autowired
	private LikeMapper likeMapper;
	
	@Override
	public boolean addLike(LikeVO likeVO) {
		int count = likeMapper.insertLike(likeVO);
		return (count == 1) ? true : false;
		
	}

	@Override
	public boolean removeLike(LikeVO likeVO) {
		int count = likeMapper.deleteLike(likeVO);
		return (count == 1 ) ? true : false;
	}

	@Override
	public boolean checkLike(LikeVO likeVO) {
		int count = likeMapper.checkLike(likeVO);
		return (count == 1) ? true : false;
	}

	@Override
	public int getLikeCount(Long bno) {
		int count = likeMapper.getLikeCount(bno);
		return count;
				
	}

}
