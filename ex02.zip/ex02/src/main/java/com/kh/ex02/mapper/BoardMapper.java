package com.kh.ex02.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.kh.ex02.domain.BoardVO;
import com.kh.ex02.domain.Criteria;

public interface BoardMapper {

	public int getTotal(Criteria cri);
	
//	@Select("select * from tbl_board order by bno desc")
	
	
	public List<BoardVO> getList(Criteria cri);
	
	public void insert(BoardVO boardVO);
	
	public Long insertSelectKey(BoardVO boardVO);
	
	public BoardVO read(Long bno);
	
	public int delete(Long bno);
	
	public int update(BoardVO boardVO);
	
	public Long selectNextval();
	
	public void updateReplycnt(@Param("bno") Long bno, 
								@Param("amount")int amount);
}
