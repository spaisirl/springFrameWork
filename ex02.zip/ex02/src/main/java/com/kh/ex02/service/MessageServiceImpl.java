package com.kh.ex02.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kh.ex02.domain.MessageVO;
import com.kh.ex02.domain.PointVO;
import com.kh.ex02.domain.ReadMessageDTO;
import com.kh.ex02.domain.SendMessageDTO;
import com.kh.ex02.mapper.MemberMapper;
import com.kh.ex02.mapper.MessageMapper;
import com.kh.ex02.mapper.PointMapper;

import lombok.extern.log4j.Log4j;
import oracle.net.ns.Message;


@Service
@Log4j
public class MessageServiceImpl implements MessageService {
	
	@Autowired
	private MessageMapper messageMapper;
	
	@Autowired
	private PointMapper pointMapper;
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Transactional
	@SuppressWarnings("unchecked")
	@Override
	public boolean sendMessage(Map<String, Object> map) {
		// map - memberVO, pointVO
		MessageVO messageVO = (MessageVO)map.get("messageVO");
		PointVO pointVO = (PointVO)map.get("pointVO");
		Map<String, Object> pointMap = (Map<String, Object>)map.get("pointMap");
		int count1 = messageMapper.insertMessage(messageVO);
		log.info("count1:" + count1);
		int count2 = pointMapper.insertPoint(pointVO);
		log.info("count2:" + count2);
		int count3 = memberMapper.updatePoint(pointMap);
		log.info("count3:" + count3);
		
		return false;
	}

	@Override
	public boolean openMessage() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getCountNotRead(String mid) {
		int count = messageMapper.getCountNotRead(mid);
		return count;
	}

	@Override
	public boolean sendMessage(SendMessageDTO sendMessageDTO) {
		
		
		String sender = sendMessageDTO.getSender();    
		String receiver = sendMessageDTO.getReceiver();  
		String mid = sendMessageDTO.getMid();      
		String message = sendMessageDTO.getMessage();
		int ppoint = sendMessageDTO.getPpoint();       
		String point_code = sendMessageDTO.getPoint_code();
		MessageVO messageVO = MessageVO.builder()
				.sender(sender)
				.receiver(receiver)
				.message(message)
				.build();
		PointVO pointVO = PointVO.builder()
				.mid(mid)
				.ppoint(ppoint)
				.point_code(point_code)
				.build();
		Map<String, Object> pointMap = new HashMap<>();
		pointMap.put("ppoint", ppoint);
		pointMap.put("mid", mid);
		int count1 = messageMapper.insertMessage(messageVO);
		log.info("count1:" + count1);
		int count2 = pointMapper.insertPoint(pointVO);
		log.info("count2:" + count2);
		int count3 = memberMapper.updatePoint(pointMap);
		return (count1+ count2 +count3 == 3) ? true : false;
	}

	@Override
	public Map<String, List<MessageVO>> listMessage(String mid) {
		List<MessageVO> sendList = messageMapper.listSend(mid);
		List<MessageVO> receiveList = messageMapper.listReceive(mid);
		Map<String, List<MessageVO>> map = new HashMap<>();
		map.put("sendList", sendList);
		map.put("receiveList", receiveList);
		return map;
	}

	@Override
	public ReadMessageDTO read(Long msg_id) {
		int count = messageMapper.updateOpenDate(msg_id);
		if (count == 1) {
			ReadMessageDTO readMessageDTO = messageMapper.selectById(msg_id);
			return readMessageDTO;
		}
		// log.info("count:"+ count);
		return null;
	}

	@Override
	public void deleteMessages(String msg_ids) {
		messageMapper.deleteByIds(msg_ids);
		
	}

	@Override
	public void checkReadByIds(String msg_ids) {
		messageMapper.updateOpenDateByIds(msg_ids);
		
	}

	@Override
	public String getOpenDate(String msg_id) {
		String open_date = messageMapper.selectOpenDateById(msg_id);
		return open_date;
	}

}
