package com.kh.ex02.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kh.ex02.domain.ReplyVO;
import com.kh.ex02.service.ReplyService;

import lombok.extern.log4j.Log4j;

@RestController
@RequestMapping("/replies")
@Log4j
public class ReplyController {
	@Autowired
	private ReplyService replySerivce;
	
	//value : 요청경로
	//consumes : 클라이언트로 부터 들어오는 데이터 타입
	//produces: 클라이언트 내보낼 데이터 타입
	@PostMapping(value = "/new", 
					consumes = MediaType.APPLICATION_JSON_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> register(@RequestBody ReplyVO replyVO) {
		log.info("replyVO:" + replyVO);
		int count = replySerivce.register(replyVO);
		boolean result = (count == 1) ? true : false;
		return new ResponseEntity<String>(String.valueOf(result),HttpStatus.OK);
	}
	
	@GetMapping(value = "/{rno}" , produces= MediaType.APPLICATION_JSON_VALUE)
	public ReplyVO get(@PathVariable("rno") Long rno) {
		ReplyVO replyVO = replySerivce.get(rno);
		return replyVO;
	}
	
	@PutMapping(value="/{rno}") 
	public String modify(@PathVariable("rno") Long rno, 
					@RequestBody ReplyVO replyVO) {
		replyVO.setRno(rno);
		log.info("replyVO" + replyVO);
		int count = replySerivce.modify(replyVO);
		return (count == 1) ? "success" : "fail";
	}
	
	@DeleteMapping("/{rno}")
	public String remove(@PathVariable ("rno") Long rno) {
		int count = replySerivce.remove(rno);
		return (count == 1 ) ? "success" : "fail";
	}	
		
	@GetMapping(value = "/list/{bno}" , 
			produces = MediaType.APPLICATION_JSON_VALUE
				)
	public List<ReplyVO> getList (@PathVariable("bno") Long bno) {
		List<ReplyVO> list = replySerivce.getList(bno);
		
		return list;
		
	}
}
