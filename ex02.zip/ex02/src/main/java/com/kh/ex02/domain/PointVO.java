package com.kh.ex02.domain;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PointVO {
	private int pid;
	private String mid;
	private int ppoint;
	private String point_code;
	private String point_desc;
	private Date regdate;
	
}
