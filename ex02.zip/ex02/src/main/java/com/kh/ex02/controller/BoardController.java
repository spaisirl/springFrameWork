package com.kh.ex02.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.kh.ex02.domain.BoardVO;
import com.kh.ex02.domain.Criteria;
import com.kh.ex02.domain.LikeVO;
import com.kh.ex02.domain.MemberVO;
import com.kh.ex02.domain.PageDTO;
import com.kh.ex02.service.BoardService;
import com.kh.ex02.service.LikeService;
import com.kh.ex02.service.MessageService;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/board/*")
@Log4j
public class BoardController {
	// test comment
	@Autowired
	private BoardService boardService;
	
	@Autowired
	private LikeService likeService;
	
	@Autowired
	private MessageService messageService;
	
	@GetMapping("/list")
	public void list(Model model, Criteria cri, HttpSession session) {
		MemberVO memberVO = (MemberVO)session.getAttribute("loginInfo");
		if (memberVO != null) {
			int countNotRead = messageService.getCountNotRead(memberVO.getMid());
			model.addAttribute("countNotRead", countNotRead);
		}
		//		log.info("cri:" + cri);
		//		log.info("boardService:" + boardService);
		
		Map<String, Object> map = boardService.getList(cri);
		@SuppressWarnings("unchecked")
		List<BoardVO> list = (List<BoardVO>)map.get("list");
		int total = (int)map.get("total");
		PageDTO pageDTO = new PageDTO(cri, total);
		log.info("pageDTO:" + pageDTO);
		model.addAttribute("pageMaker", pageDTO);
		model.addAttribute("list", list);
	}
	
	@GetMapping("/register")
	public void registerGet() {
		
	}
	
	@PostMapping("/register")
	public String registerPost(HttpSession session, BoardVO boardVO, RedirectAttributes rttr) {
		MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
		String mid = loginInfo.getMid();
		boardVO.setWriter(mid);
		// 폼에서 넘어온 데이터를 확인
		log.info("boardVO:" + boardVO);
		Long bno = boardService.register(boardVO);
		log.info("bno:" + bno);
		rttr.addFlashAttribute("result", bno);
		return "redirect:/board/list";
	}
	
	@GetMapping({"/get", "/modify"})
	public void get(HttpSession session, Long bno, Criteria criteria, Model model) {
		BoardVO boardVO = boardService.get(bno);
		int likeCount = likeService.getLikeCount(bno);
		MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
		String mid = loginInfo.getMid();
		LikeVO likeVo = LikeVO.builder()
				.mid(mid)
				.bno(bno)
				.build();
		boolean checkLike = likeService.checkLike(likeVo);
		Map<String, Object> likeMap = new HashMap<>();
		likeMap.put("likeCount", likeCount);
		likeMap.put("checkLike", checkLike);
		log.info("boardVO:" + boardVO);
		log.info("criteria:" + criteria);
		PageDTO pageDTO = new PageDTO();
		pageDTO.setCriteria(criteria);
		model.addAttribute("pageMaker", pageDTO); // pageMaker-view 
		model.addAttribute("boardVO", boardVO);
		model.addAttribute("likeMap", likeMap);
	}
	
	@PostMapping("/modify")
	public String modify(HttpSession session, BoardVO boardVO, Criteria criteria, RedirectAttributes rttr) {
		MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
		boardVO.setWriter(loginInfo.getMid());
		log.info("boardVO:" + boardVO);
		log.info("modifyPost, criteria:" + criteria);
		boolean result = boardService.modify(boardVO);
		rttr.addFlashAttribute("modifyResult", result);
		rttr.addAttribute("pageNum", criteria.getPageNum());
		rttr.addAttribute("amount", criteria.getAmount());
		rttr.addAttribute("bno", boardVO.getBno());
		rttr.addAttribute("type", criteria.getType());
		rttr.addAttribute("keyword", criteria.getKeyword());
		return "redirect:/board/get";
	}
	
	@PostMapping("/remove")
	public String remove(Long bno, Criteria criteria, RedirectAttributes rttr) {
		boolean result = boardService.remove(bno);
		rttr.addFlashAttribute("removeResult", result);
		rttr.addAttribute("pageNum", criteria.getPageNum());
		rttr.addAttribute("amount", criteria.getAmount());
		rttr.addAttribute("type", criteria.getType());
		rttr.addAttribute("keyword", criteria.getKeyword());
		
		return "redirect:/board/list";
	}
}
