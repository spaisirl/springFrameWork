package com.kh.ex02.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kh.ex02.domain.MemberVO;
import com.kh.ex02.domain.MessageVO;
import com.kh.ex02.domain.ReadMessageDTO;
import com.kh.ex02.domain.SendMessageDTO;
import com.kh.ex02.service.MessageService;

import lombok.extern.log4j.Log4j;
import oracle.jdbc.driver.Message;
import oracle.jdbc.proxy.annotation.Post;

@Log4j
@Controller
@RequestMapping("/message")
public class MessageController {
	@Autowired
	private MessageService messageService;
	
	@PostMapping("/sendMessage")
	@ResponseBody
	public String sendMessage(SendMessageDTO sendMessageDTO,MessageVO messageVO, HttpSession session) {
		MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
		sendMessageDTO.setSender(loginInfo.getMid());
		sendMessageDTO.setMid(loginInfo.getMid());
		log.info("sendMessageDTO:" + sendMessageDTO);
		boolean result = messageService.sendMessage(sendMessageDTO);
		return String.valueOf(result);
	}
	
	@GetMapping(value = "/getCountNotRead",
				produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String getCountNotRead(HttpSession session) {
		MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
		int count = 0;
		if (loginInfo != null) {
			String mid = loginInfo.getMid();
			count = messageService.getCountNotRead(mid);
		}
		return String.valueOf(count);
	}
	
	@GetMapping("/list")
	public void list(Model model, HttpSession session) {
		MemberVO loginInfo = (MemberVO) session.getAttribute("loginInfo");
		String mid = loginInfo.getMid();
		Map<String, List<MessageVO>> messageMap = 
				messageService.listMessage(mid);
		model.addAttribute("messageMap", messageMap);
	}
	
	@PostMapping(value = "/read", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ReadMessageDTO read(Long msg_id) {
		
		log.info("msg_id: " + msg_id);
		ReadMessageDTO readMessageDTO  = messageService.read(msg_id);
		return readMessageDTO; // "true" / "false"
	}
	
	@PostMapping("/delete")
	@ResponseBody
	public String delete(String msg_ids) {
		log.info("msg_ids:" + msg_ids);
		messageService.deleteMessages(msg_ids);
		return "success";
	}
	
	@PostMapping(value = "/checkRead")
	@ResponseBody
	public String chkRead(String msg_ids) {
		log.info("msg_ids:" + msg_ids);
		messageService.checkReadByIds(msg_ids);
		String open_date = messageService.getOpenDate(msg_ids.split(",")[0]);
	    
		return open_date;
	}
	

}
