package com.kh.ex02.service;

public interface SampleTXService {
	
	public void addData(String value);
}
