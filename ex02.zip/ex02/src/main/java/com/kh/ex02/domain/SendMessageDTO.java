package com.kh.ex02.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SendMessageDTO {
	private String sender;
	private String receiver;
	private String message;
	private String mid;
	private int ppoint;
	private String point_code;

}
