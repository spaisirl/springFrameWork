package com.kh.ex02.service;

import java.util.List;
import java.util.Map;

import com.kh.ex02.domain.MessageVO;
import com.kh.ex02.domain.ReadMessageDTO;
import com.kh.ex02.domain.SendMessageDTO;

public interface MessageService {
	
	public boolean sendMessage(Map<String, Object> map);
	public boolean sendMessage(SendMessageDTO sendMessageDTO);
	public boolean openMessage();
	public int getCountNotRead(String mid);
	public Map<String, List<MessageVO>> listMessage(String mid);
	public ReadMessageDTO read(Long msg_id);
	public void deleteMessages(String msg_ids);
	public void checkReadByIds(String msg_ids);
	public String getOpenDate(String msg_id);
	
}
