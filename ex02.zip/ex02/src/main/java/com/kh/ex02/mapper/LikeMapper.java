package com.kh.ex02.mapper;

import com.kh.ex02.domain.LikeVO;

public interface LikeMapper {
	
	public int insertLike(LikeVO likeVO);
	public int deleteLike(LikeVO likeVO);
	public int checkLike(LikeVO likeVO);
	public int getLikeCount(Long bno);

}
