package com.kh.ex02.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.ex02.domain.BoardAttachVO;
import com.kh.ex02.mapper.BoardAttachMapper;

@Service
public class BoardAttachServiceImpl implements BoardAttachService {
	@Autowired
	private BoardAttachMapper boardAttachMapper;

	@Override
	public List<BoardAttachVO> findByBno(Long bno) {
		List<BoardAttachVO> attachList = boardAttachMapper.findByBno(bno);
		return attachList;
	}
	
	
}
