package com.kh.ex02.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
public class HomeController {
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		
		return "redirect:/board/list";
	}
	
	
	@GetMapping("/doA")
	public void doA(int age, String name) {
		log.info("doA");
		//Integer.parseInt("백");
	}
	
	@GetMapping("/doB")
	public void doB() {
		log.info("doB");
	}
	
	@GetMapping("/doC")
	public void doC() {
		log.info("doC");
	}
	
}
