package com.kh.ex02.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageVO {
	private Long msg_id;
	private String sender;
	private String receiver;
	private String message;
	private Date send_date;
	private Date open_date;

}
