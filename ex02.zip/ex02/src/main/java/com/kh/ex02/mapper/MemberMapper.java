package com.kh.ex02.mapper;

import java.util.Map;

import com.kh.ex02.domain.LoginDTO;
import com.kh.ex02.domain.MemberVO;

public interface MemberMapper {
	
	public MemberVO login(LoginDTO loginDTO);
	
	public int registerPost(MemberVO memberVO);
	
	public int updatePoint(Map<String, Object> map);

}
