package com.kh.ex02.interceptor;

import java.util.Map;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.kh.ex02.domain.MemberVO;

import lombok.extern.log4j.Log4j;

// 회원 로그인 시 글쓰기 가능하게

@Log4j
public class AuthInterceptor extends HandlerInterceptorAdapter{
	
	@Override
	public boolean preHandle(HttpServletRequest request, 
			HttpServletResponse response, Object handler)
			throws Exception {
		log.info("preHandle");
		HttpSession session = request.getSession();
		MemberVO memberVO = (MemberVO)session.getAttribute("loginInfo");
		if (memberVO == null) {
			saveTargetLocation(request);
			response.sendRedirect("/login");
			return false;
		}
		return true;
		
	}
	
	private void saveTargetLocation(HttpServletRequest request) {
		String uri = request.getRequestURI();
		log.info("uri:" + uri);
		String query = request.getQueryString();
		log.info("query:" + query);
		String method = request.getMethod();
		log.info("method:" + method);
		if(method.equals("GET")) {
			if (query == null || query.equals("null")) {
				query = "";
			} else {
				query = "?" + query;
			}
		}
		String targetLoaction = uri +query;
		request.getSession().setAttribute("targetLocation", targetLoaction);
	}
	
	
	
}
