package com.kh.ex02.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AttachFileDTO {
	private String fileName;
	private String uploadPath;
	private String uuid;
	private boolean image;
}
