package com.kh.ex02.service;

import java.util.List;

import com.kh.ex02.domain.BoardAttachVO;

public interface BoardAttachService {
	
	public List<BoardAttachVO> findByBno(Long bno);
	
}
