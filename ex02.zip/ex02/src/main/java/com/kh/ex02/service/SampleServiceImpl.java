package com.kh.ex02.service;

import org.springframework.stereotype.Service;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class SampleServiceImpl implements SampleService {

	@Override
	public Integer doAdd(String str1, String str2) throws Exception {
		
		log.info("doAdd..");
		return Integer.parseInt(str1) + Integer.parseInt(str2);
		
	}
	
	

	@Override
	public Integer doSub(String str1, String str2) throws Exception {
		
		log.info("doSub..");
		return Integer.parseInt(str1) - Integer.parseInt(str2);
	}
	
}
