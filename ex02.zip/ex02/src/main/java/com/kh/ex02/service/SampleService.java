package com.kh.ex02.service;

public interface SampleService {
	
	public Integer doAdd(String str1, String str2) throws Exception;
	public Integer doSub(String str1, String str2) throws Exception;
}
