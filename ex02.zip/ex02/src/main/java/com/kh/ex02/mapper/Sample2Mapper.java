package com.kh.ex02.mapper;

public interface Sample2Mapper {
	public int insertCol2(String data);
}
