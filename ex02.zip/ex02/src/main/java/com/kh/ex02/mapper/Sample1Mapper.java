package com.kh.ex02.mapper;

public interface Sample1Mapper {
	
	public int insertCol1(String data);
}
