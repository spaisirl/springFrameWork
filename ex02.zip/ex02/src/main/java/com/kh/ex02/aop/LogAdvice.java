package com.kh.ex02.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j;

@Aspect
@Component
@Log4j
public class LogAdvice {
	
//	@Before ("execution(* com.kh.ex02.service.SampleService*.*(..))")
//	public void logBefore() {
//		log.info("========= logBefore ========");
//	}
//	
//	@Before ("execution(* com.kh.ex02.service.SampleService*.doAdd(..)) &&args(str1, str2)")
//	public void logBeforeWithParam(String str1, String str2) {
//		log.info("str1:" + str1);
//		log.info("str2:" + str2);
//	}
//	
//	@After ("execution(* com.kh.ex02.service.SampleService*.*(..))")
//	public void logAfter() {
//		log.info("========= logAfter ========");
//	}
//	
//	@AfterThrowing(pointcut = "execution(* com.kh.ex02.service.SampleService*.*(..))", 
//			throwing = "exception") 
//	public void logException(Exception exception){
//		log.error("에러발생");
//		log.info(exception.getMessage());
//	}
	
	@Around ("execution(* com.kh.ex02.service.SampleService*.*(..))")
	public Object logTime(ProceedingJoinPoint pjp) {
		// 타겟의 joinpoint의 리턴타입
		log.info("======== before logtime ========");
		Integer result = 0;
		long startTime = System.currentTimeMillis();
		// ------------------------------------------
		try {
			log.info("target: " + pjp.getTarget());
			Object[] args = pjp.getArgs();
			for (Object arg : args ) {
				log.info("arg"+arg);
			}
			result = (Integer)pjp.proceed(); // 실제 메서드 실행
		} catch (Throwable e) {
			
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		log.info("걸린시간:" + (endTime - startTime));
		log.info("========= after logtime =========");
		return result;
	}
}
