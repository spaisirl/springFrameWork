package com.kh.ex02.service;


import com.kh.ex02.domain.LikeVO;

public interface LikeService {
	public boolean addLike(LikeVO likeVO);
	public boolean removeLike(LikeVO likeVO);
	public boolean checkLike(LikeVO likeVO);
	public int getLikeCount(Long bno);
}
