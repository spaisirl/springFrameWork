package com.kh.ex02.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kh.ex02.domain.LikeVO;
import com.kh.ex02.domain.MemberVO;
import com.kh.ex02.service.LikeService;

@RestController
@RequestMapping("/like")
public class LikeController {
	
	@Autowired
	private LikeService likeService;
	
	@PostMapping("/addLike/{bno}")
	public String addLike(HttpSession session, 
			@PathVariable("bno") Long bno) {
		LikeVO likeVO = LikeVO.builder()
				.mid(((MemberVO)session.getAttribute("loginInfo")).getMid())
				.bno(bno)
				.build();
		boolean result = likeService.addLike(likeVO);
		return String.valueOf(result); // "true" / "false"
	}
	
	@PostMapping("/removeLike/{bno}")
	public String removeLike(HttpSession session, @PathVariable("bno") Long bno) {
		LikeVO likeVo = LikeVO.builder()
				.mid(((MemberVO)session.getAttribute("loginInfo")).getMid())
				.bno(bno)
				.build();
		boolean result = likeService.removeLike(likeVo);
		return String.valueOf(result);
	}
	
	

}
