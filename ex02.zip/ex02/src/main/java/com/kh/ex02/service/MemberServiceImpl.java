package com.kh.ex02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.ex02.domain.LoginDTO;
import com.kh.ex02.domain.MemberVO;
import com.kh.ex02.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberSerivce {
	@Autowired
	public MemberMapper memberMapper;

	@Override
	public MemberVO login(LoginDTO loginDTO) {
		MemberVO memberVO = memberMapper.login(loginDTO);
		return memberVO;
	}

	@Override
	public boolean registerPost(MemberVO memberVO) {
		int count = memberMapper.registerPost(memberVO);
		if (count == 1) {
			return true;
		}
		memberMapper.registerPost(memberVO);
		return false;
	}
	
}
