drop table tbl_point;
drop table tbl_point_code;
drop sequence seq_pid;

create table tbl_point_code(
	point_code char(2)
		constraint pk_point_code primary key,
	point_desc varchar2(100) not null
);

create table tbl_point(
	pid number
		constraint pk_pid primary key,
	mid varchar2(50)
		constraint  fk_mid 
			references tbl_member(mid),
	ppoint number not null,
	point_code char(2) 
		constraint fk_point_code
			references tbl_point_code(point_code),
	regdate date default sysdate
);


create sequence seq_pid;

insert into tbl_point_code(point_code, point_desc)
values ('MS', '쪽지 보내기');
insert into tbl_point_code(point_code, point_desc)
values ('MR', '쪽지 읽기');
insert into tbl_point_code(point_code, point_desc)
values ('PS', '포인트 선물하기');
insert into tbl_point_code(point_code, point_desc)
values ('PR', '포인트 선물받기');

-- 쪽지 테이블

create tabel tbl_message(
	msg_id
		constraint pk_msg_id primary key,
	sender varchar2(50)
		constraint fk_sender
			references tbl_member(mid),
	receiver varchar2(50)
		constraint fk_receiver
			reference tbl_member(mid),
	message varchar2(500),
	send_date date sysdate,
	open_date date
);

create sequence seq_msg_id;