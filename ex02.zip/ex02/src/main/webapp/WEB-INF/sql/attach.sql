-- 첨부파일 테이블 생성
create table tbl_attach(
    uuid varchar2(100)
        constraint pk_uuid primary key,
    upload_Path varchar2(200),
    file_Name varchar2(100),
    file_type char(1) default 'I',
    bno number
        constraint fk_bno
            references tbl_board(bno)
);