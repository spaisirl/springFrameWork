create table tbl_like(
	mid varchar2(50)
		constraint fk_like_mid references tbl_member(mid),
	bno number
		constraint fk_like_bno references tbl_board(bno)
);

insert into tbl_like(mid, bno) values ('MEMBER00', 500);
insert into tbl_like(mid, bno) values ('MEMBER01', 500);

commit;

select * from tbl_like;

SELECT COUNT(*) FROM TBL_LIKE
WHERE BNO = 500; -- 현재글의 좋아요 갯수

select count(*) from tbl_like
where mid = 'MEMBER00' AND BNO = 500; -- 좋아요 함

select count(*) from tbl_like
where mid = 'MEMBER02' AND BNO = 500; -- 좋아요 안함

DELETE FROM TBL_LIKE
WHERE MID = 'MEMBER01' AND BNO = 500; -- 좋아요 취소