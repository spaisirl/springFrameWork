create table tbl_board(
    bno number primary key,         -- 글번호
    title varchar2(200) not null,   -- 글제목
    content varchar2(2000) not null,-- 글내용
    writer varchar2(50) not null,   -- 작성자
    regdate date default sysdate,   -- 작성일
    updatedate date default sysdate -- 수정일
);

create sequence seq_board;

begin
    for i in 1..10 loop
        insert into tbl_board(bno, title, content, writer)
        values (seq_board.nextval, '제목-' || i, 
        		'내용-' || i, 'user-' || i);
    end loop;
end;
/

select * from tbl_board;
commit

--댓글 테이블
create table tbl_reply(
    rno number
        constraint pk_reply primary key, -- 댓글 번호
    bno number
        constraint fk_reply references tbl_board(bno), -- 글번호
    reply varchar2(1000) not null, -- 댓글 내용
    replyer varchar2(50) not null, -- 댓글러
    replydate date default sysdate, -- 작성일
    updatedate date default sysdate -- 수정일
);

-- 댓글 시퀀스
create sequence seq_reply;
