create table tbl_member(
    mid varchar2(50)
        constraint pk_memeber primary key,
    mpw varchar2(50) not null,
    mname varchar2(100) not null,
    mpoint number default 0
);

insert into tbl_member(mid, mpw, mname) values('MEMBER00', 'MEMBER00', 'IRON MAN');
insert into tbl_member(mid, mpw, mname) values('MEMBER01', 'MEMBER01', 'CAPTAIN');
insert into tbl_member(mid, mpw, mname) values('MEMBER02', 'MEMBER02', 'HULK');
insert into tbl_member(mid, mpw, mname) values('MEMBER03', 'MEMBER03', 'THOR');

commit;

select * from tbl_member;

UPDATE TBL_BOARD SET
    WRITER = 'MEMBER00';
    
    COMMIT;
    
UPDATE TBL_REPLY SET
    REPLYER = 'MEMBER00';
    
    COMMIT;
    
ALTER TABLE TBL_BOARD
    ADD CONSTRAINT FK_WRITER
       FOREIGN KEY(WRITER) REFERENCES TBL_MEMBER (MID);
       
ALTER TABLE TBL_REPLY
    ADD CONSTRAINT FK_REPLYER
       FOREIGN KEY(REPLYER) REFERENCES TBL_MEMBER (MID);
       
-- 쪽지 테이블

create table tbl_message(
	msg_id number constraint pk_msg_id primary key,
	sender varchar2(50) constraint fk_sender references tbl_member(mid),
	receiver varchar2(50) constraint fk_receiver references tbl_member(mid),
	message varchar2(500),
	send_date date default sysdate,
	open_date date
);

create sequence seq_msg_id;

SELECT * FROM TBL_MESSAGE;
SELECT * FROM TBL_POINT;
SELECT * FROM TBL_MEMBER WHERE MID = 'MEMBER00';

select * from user_sequences;